package com.nttdata.proyecto.BankProduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
