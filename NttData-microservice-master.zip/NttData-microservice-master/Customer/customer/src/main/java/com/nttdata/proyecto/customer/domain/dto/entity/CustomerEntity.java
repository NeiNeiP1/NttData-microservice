package com.nttdata.proyecto.customer.domain.dto.entity;

public class CustomerEntity {
}
