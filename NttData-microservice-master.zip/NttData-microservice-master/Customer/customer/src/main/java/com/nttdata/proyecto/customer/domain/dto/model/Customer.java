package com.nttdata.proyecto.customer.domain.dto.model;

public class Customer {
}
